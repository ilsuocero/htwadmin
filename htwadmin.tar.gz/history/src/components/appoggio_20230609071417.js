{
    "identity": 80,
        "labels": [
            "Nodo"
        ],
            "properties": {
        "geoFence": 30.0,
            "tipo": "destinazione",
                "nome": "Zucca Uomo",
                    "id": "0f53a703-9633-4f3a-b435-b3c5185a90b7",
                        "ID": 1686079810350205200.0,
                            "coords": [
                                9.515350478973943,
                                44.883012551506
                            ]
    }
}
{
    "identity": 9,
        "labels": [
            "Nodo"
        ],
            "properties": {
        "tipo": "destinazione",
            "geoFence": 30,
                "location": point({ srid: 4326, x: 44.87893459873299, y: 9.505142339638764 }),
                    "nome": "Pradello",
                        "id": "81c3858f-58ad-42a0-a659-1ed7db9ae86f",
                            "ID": 2010009,
                                "coords": [
                                    9.505142339638764,
                                    44.87893459873299
                                ]
    }
}
geoFence: 20.0