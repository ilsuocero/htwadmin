export const useCrossRoadForm = (showForm, setCrossRoads, map, mapContainer) => {
    useEffect(() => {
        // Your code here

        // ...

    }, [showForm.show, showForm.coordinates]);
};r